package com.naacab.census.controller;

import com.naacab.census.dto.PersonData;
import com.naacab.census.service.CensusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/census")
@EnableSwagger2
public class CensusController {

    @Autowired
    CensusService censusService;

    @GetMapping("/fetchAllCensusData")
    public List<PersonData> fetchAllPersonDetails(){
        return censusService.getAllPersonDataServ();
    }
    @GetMapping("/fetchOnId/{id}")
    public Optional<PersonData> fetchDataOnId(@RequestParam("id") Integer id){
        return censusService.getPersonOnIdServ(id);
    }

    @PostMapping("/addPersonData")
    public String addPerson(@RequestBody  PersonData personData){
        return  censusService.addPerson(personData);
    }
}
