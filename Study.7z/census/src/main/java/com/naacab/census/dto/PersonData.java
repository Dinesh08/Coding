package com.naacab.census.dto;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity(name = "PERSON_DATA")
public class PersonData {

    @Id
    @Column(name = "ID" )
    public int id;
    @Column(name = "FIRST_NAME")
    public String firstName;
    @Column(name = "LAST_NAME")
    public String lastName;
    @Column(name = "MIDDLE_NAME")
    public String middleName;
    @Column(name = "AGE")
    public String age;
    @Column(name = "RELIGION")
    public String religion;
    @Column(name = "CITY")
    public String city;
    @Column(name = "STATE")
    public String state;
    @Column(name = "REGION")
    public String region;
    @Column(name = "DATE_OF_BIRTH")
    public String dateOfBirth;
    @Column(name = "EDUCATION")
    public String education;
    @Column(name = "GENDER")
    public String gender;
    @Column(name = "MARITAL_STATUS")
    public String maritalStatus;
    @Column(name = "NO_OF_CHILDREN")
    public int noOfChildren;
    @Column(name = "NO_OF_SPOUSE")
    public int noOfSpouse;
    @Column(name = "IS_DIVORCED")
    public boolean isDivorced;
    @Column(name = "IS_EMPLOYED")
    public boolean isEmployed;
    @Column(name = "ANNUAL_INCOME")
    public String annualIncome;
    @Column(name = "HAS_OWN_VEHICLE")
    public boolean hasOwnVehicle;
    @Column(name = "HAS_OWN_HOUSE")
    public boolean hasOwnHouse;
    @Column(name = "PERSON_NATIVE")
    public String personNative;
    @Column(name = "MOTHER_TOUNGE")
    public String motherTounge;
    @Column(name = "PLACE_OF_BIRTH")
    public String placeOfBirth;
    @Column(name = "PHONE_NUMBER")
    public String phoneNUmber;
    @Column(name = "AADHAR_NUMBER")
    public String aadharNumber;

//    //for NRC and CAB
//    public boolean isTourist;
//    public boolean isResident;
//    public boolean hasValidVisa;
//    public boolean isInfiltrated;
//    public boolean isConverted;
//    public String previousReligion;
//    public String currentReligion;
//    //date of expiry
//    public String touristVisaEndsDate;
//
//    public String migratedFrom;
//    public String migratedDate;
//    public String community;
//    public String noOfDaysLived;
//    public String civilConductRemarks;


}
