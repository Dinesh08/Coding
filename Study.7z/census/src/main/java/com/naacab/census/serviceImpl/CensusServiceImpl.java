package com.naacab.census.serviceImpl;

import com.naacab.census.dto.PersonData;
import com.naacab.census.repository.CensusRepository;
import com.naacab.census.service.CensusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CensusServiceImpl implements CensusService {

    @Autowired
    CensusRepository crudRepo;

    @Override
    public List<PersonData> getAllPersonDataServ() {
        List<PersonData> res = new ArrayList<>();
         crudRepo.findAll().forEach(res::add);
        return res;
    }

    @Override
    public Optional<PersonData> getPersonOnIdServ(int id) {
        return crudRepo.findById(id);
    }

    @Override
    public String addPerson(PersonData personData) {
        crudRepo.save(personData);
        return "added";
    }


}
