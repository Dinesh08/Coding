package com.naacab.census.repository;

import com.naacab.census.dto.PersonData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface CensusRepository  extends CrudRepository<PersonData, Integer> {

}
