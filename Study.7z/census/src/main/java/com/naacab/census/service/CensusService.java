package com.naacab.census.service;

import com.naacab.census.dto.PersonData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

public interface CensusService {
    public List<PersonData> getAllPersonDataServ();
    public Optional<PersonData> getPersonOnIdServ(int id);
    public String addPerson(PersonData personData);
}
