package com.naacab.census.Configurations;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
}
