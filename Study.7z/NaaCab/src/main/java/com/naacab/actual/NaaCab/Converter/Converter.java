/*
 * package com.naacab.actual.NaaCab.Converter;
 * 
 * import com.naacab.actual.NaaCab.NaaCabDto.DomainEntity; import
 * com.naacab.actual.NaaCab.NaaCabDto.DomainModels;
 * 
 * import java.util.Optional;
 * 
 * public class Converter {
 * 
 * public DomainEntity convertDomainModelsToEntity(DomainModels models){
 * DomainEntity entity = new DomainEntity();
 * entity.setCivilConductRemarks(models.getCivilConductRemarks());
 * entity.setName(models.getPersonName());
 * entity.setCommunity(models.getCommunity());
 * entity.setCurrentLocation(models.getCurrentLocation());
 * entity.setCurrentReligion(models.getCurrentReligion());
 * entity.setDescription(models.getAnyOtherDetailedDescriptions());
 * entity.setCivilConductRemarks(models.getCivilConductRemarks());
 * entity.setHasValidVisa(models.getHasValidVisa());
 * entity.setId(models.getId());
 * entity.setIsConverted(models.getIsConvertedFromPreviousReligion());
 * entity.setIsInfiltrated(models.getIsInfiltratedFromAnotherCountry());
 * entity.setIsResident(models.getIsResidentOfIndia());
 * entity.setIsTourist(models.getIsResidentOfIndia());
 * entity.setMigratedDate(models.getMigratedDate());
 * entity.setMigratedFrom(models.getMigratedFrom());
 * entity.setNoOfDaysLivedInCurrentLocation(models.
 * getNoOfDaysLivedInCurrentLocation());
 * entity.setPreviousReligion(models.getPreviousReligion());
 * entity.setTouristVisaEndsDate(models.getTouristVisaExpiry()); return entity;
 * } public DomainModels convertDomainEntityToModels(DomainEntity entity){
 * DomainModels model=new DomainModels();
 * model.setAnyOtherDetailedDescriptions(entity.getDescription());
 * model.setCivilConductRemarks(entity.getCivilConductRemarks());
 * model.setCommunity(entity.getCommunity());
 * model.setIsConvertedFromPreviousReligion(entity.getIsConverted());
 * model.setCurrentLocation(entity.getCurrentLocation());
 * model.setHasValidVisa(entity.getHasValidVisa());
 * model.setCurrentReligion(entity.getCurrentReligion()); //
 * model.setId(entity.getId()); model.setPersonName(entity.getName());
 * model.setIsInfiltratedFromAnotherCountry(entity.getIsInfiltrated());
 * model.setIsResidentOfIndia(entity.getIsResident());
 * model.setIsTouristOfIndia(entity.getIsTourist());
 * model.setMigratedDate(entity.getMigratedDate());
 * model.setMigratedFrom(entity.getMigratedFrom());
 * model.setNoOfDaysLivedInCurrentLocation(entity.
 * getNoOfDaysLivedInCurrentLocation());
 * model.setTouristVisaExpiry(entity.getTouristVisaEndsDate());
 * model.setPreviousReligion(entity.getPreviousReligion()); return model; } }
 */