package com.naacab.actual.NaaCab.serviceImpl;


import com.naacab.actual.NaaCab.NaaCabDto.DomainEntity;
import com.naacab.actual.NaaCab.NaaCabDto.DomainModels;
import com.naacab.actual.NaaCab.Repository.NrcCaaRepository;
import com.naacab.actual.NaaCab.Service.CaaNrcService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CaaNrcServiceImpl implements CaaNrcService {
    @Autowired
    NrcCaaRepository nrcCaaRepository;

    @Override
    public List<DomainEntity> fetchAllListData() {
        List<DomainEntity> allDetails = new ArrayList<>();
        //List<DomainModels> model = new ArrayList<>();
        nrcCaaRepository.findAll().forEach(allDetails::add);
		/*
		 * allDetails.forEach(e->{
		 * model.add(dtoConversion.convertDomainEntityToModels(e)); });
		 */
        return allDetails;
    }

    public DomainEntity fetchPersonDataById(Integer id) {
        
        return nrcCaaRepository.findById(id).orElse(null);
    }

    @Override
    public String addPersonDetail(DomainEntity model) {
      //  DomainEntity entity  = dtoConversion.convertDomainModelsToEntity(model);
        nrcCaaRepository.save(model);
        return "success";
    }
}
