package com.naacab.actual.NaaCab.NaaCabDto;

import lombok.*;

public class DomainModels {

    //for NRC and CAB
    public int id;
    public String isTouristOfIndia;
    public String personName;
    public String isResidentOfIndia;
    public String hasValidVisa;
    public String isInfiltratedFromAnotherCountry;
    public String isConvertedFromPreviousReligion;
    public String previousReligion;
    public String currentReligion;
    public String touristVisaExpiry;
    public String migratedFrom;
    public String migratedDate;
    public String community;
    public String currentLocation;
    public String noOfDaysLivedInCurrentLocation;
    public String civilConductRemarks;
    public String anyOtherDetailedDescriptions;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIsTouristOfIndia() {
		return isTouristOfIndia;
	}
	public void setIsTouristOfIndia(String isTouristOfIndia) {
		this.isTouristOfIndia = isTouristOfIndia;
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getIsResidentOfIndia() {
		return isResidentOfIndia;
	}
	public void setIsResidentOfIndia(String isResidentOfIndia) {
		this.isResidentOfIndia = isResidentOfIndia;
	}
	public String getHasValidVisa() {
		return hasValidVisa;
	}
	public void setHasValidVisa(String hasValidVisa) {
		this.hasValidVisa = hasValidVisa;
	}
	public String getIsInfiltratedFromAnotherCountry() {
		return isInfiltratedFromAnotherCountry;
	}
	public void setIsInfiltratedFromAnotherCountry(String isInfiltratedFromAnotherCountry) {
		this.isInfiltratedFromAnotherCountry = isInfiltratedFromAnotherCountry;
	}
	public String getIsConvertedFromPreviousReligion() {
		return isConvertedFromPreviousReligion;
	}
	public void setIsConvertedFromPreviousReligion(String isConvertedFromPreviousReligion) {
		this.isConvertedFromPreviousReligion = isConvertedFromPreviousReligion;
	}
	public String getPreviousReligion() {
		return previousReligion;
	}
	public void setPreviousReligion(String previousReligion) {
		this.previousReligion = previousReligion;
	}
	public String getCurrentReligion() {
		return currentReligion;
	}
	public void setCurrentReligion(String currentReligion) {
		this.currentReligion = currentReligion;
	}
	public String getTouristVisaExpiry() {
		return touristVisaExpiry;
	}
	public void setTouristVisaExpiry(String touristVisaExpiry) {
		this.touristVisaExpiry = touristVisaExpiry;
	}
	public String getMigratedFrom() {
		return migratedFrom;
	}
	public void setMigratedFrom(String migratedFrom) {
		this.migratedFrom = migratedFrom;
	}
	public String getMigratedDate() {
		return migratedDate;
	}
	public void setMigratedDate(String migratedDate) {
		this.migratedDate = migratedDate;
	}
	public String getCommunity() {
		return community;
	}
	public void setCommunity(String community) {
		this.community = community;
	}
	public String getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}
	public String getNoOfDaysLivedInCurrentLocation() {
		return noOfDaysLivedInCurrentLocation;
	}
	public void setNoOfDaysLivedInCurrentLocation(String noOfDaysLivedInCurrentLocation) {
		this.noOfDaysLivedInCurrentLocation = noOfDaysLivedInCurrentLocation;
	}
	public String getCivilConductRemarks() {
		return civilConductRemarks;
	}
	public void setCivilConductRemarks(String civilConductRemarks) {
		this.civilConductRemarks = civilConductRemarks;
	}
	public String getAnyOtherDetailedDescriptions() {
		return anyOtherDetailedDescriptions;
	}
	public void setAnyOtherDetailedDescriptions(String anyOtherDetailedDescriptions) {
		this.anyOtherDetailedDescriptions = anyOtherDetailedDescriptions;
	}
	@Override
	public String toString() {
		return "DomainModels [id=" + id + ", isTouristOfIndia=" + isTouristOfIndia + ", personName=" + personName
				+ ", isResidentOfIndia=" + isResidentOfIndia + ", hasValidVisa=" + hasValidVisa
				+ ", isInfiltratedFromAnotherCountry=" + isInfiltratedFromAnotherCountry
				+ ", isConvertedFromPreviousReligion=" + isConvertedFromPreviousReligion + ", previousReligion="
				+ previousReligion + ", currentReligion=" + currentReligion + ", touristVisaExpiry=" + touristVisaExpiry
				+ ", migratedFrom=" + migratedFrom + ", migratedDate=" + migratedDate + ", community=" + community
				+ ", currentLocation=" + currentLocation + ", noOfDaysLivedInCurrentLocation="
				+ noOfDaysLivedInCurrentLocation + ", civilConductRemarks=" + civilConductRemarks
				+ ", anyOtherDetailedDescriptions=" + anyOtherDetailedDescriptions + "]";
	}
    
    
}
