package com.naacab.actual.NaaCab.Service;

import com.naacab.actual.NaaCab.NaaCabDto.DomainEntity;
import com.naacab.actual.NaaCab.NaaCabDto.DomainModels;

import java.util.List;
import java.util.Optional;

public interface CaaNrcService {
    public List<DomainEntity> fetchAllListData();
    public DomainEntity fetchPersonDataById(Integer id);
    public String addPersonDetail(DomainEntity model);
}
