package com.naacab.actual.NaaCab.Controller;

import com.naacab.actual.NaaCab.NaaCabDto.DomainEntity;
import com.naacab.actual.NaaCab.NaaCabDto.DomainModels;
import com.naacab.actual.NaaCab.Service.CaaNrcService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/caanrc")
public class NrcCabController {

    @Autowired
    CaaNrcService caaNrcService;

    @GetMapping("/fetchAll")
    public ResponseEntity<List<DomainEntity>> getAllPersonDetails(){
        return new ResponseEntity<>(caaNrcService.fetchAllListData(), HttpStatus.OK);
    }

    @GetMapping("fetchById/{id}")
    public ResponseEntity<DomainEntity> getPersonDetailsById(@RequestParam Integer id){
        return new ResponseEntity<DomainEntity>(caaNrcService.fetchPersonDataById(id), HttpStatus.OK);
    }

    @PostMapping("/addPersonEntry")
    public ResponseEntity<String> addPersonDetail(@RequestBody DomainEntity modelData){
        return new ResponseEntity<>(caaNrcService.addPersonDetail(modelData),HttpStatus.CREATED);
    }
}
