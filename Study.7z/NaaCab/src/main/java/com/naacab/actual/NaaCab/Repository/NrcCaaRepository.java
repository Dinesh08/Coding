package com.naacab.actual.NaaCab.Repository;

import com.naacab.actual.NaaCab.NaaCabDto.DomainEntity;
import com.naacab.actual.NaaCab.NaaCabDto.DomainModels;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NrcCaaRepository extends CrudRepository<DomainEntity, Integer> {
}
