package com.naacab.actual.NaaCab.NaaCabDto;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "NRC_DETAILS")
public class DomainEntity {

    //for NRC and CAB
    @Id
    @Column(name = "ID" )
    public int id;

    @Column(name="PERSON_NAME")
    public String name;

    @Column(name = "IS_TOURISTS" )
    public String isTourist;

    @Column(name = "IS_RESIDENTS" )
    public String isResident;

    @Column(name = "HAS_VALID_VISA" )
    public String hasValidVisa;

    @Column(name = "IS_INFLITRATED" )
    public String isInfiltrated;

    @Column(name = "IS_CONVERTED" )
    public String isConverted;

    @Column(name = "PREVIOUS_RELIGION" )
    public String previousReligion;

    @Column(name = "CURRENT_RELIGION" )
    public String currentReligion;

    @Column(name = "TOURIST_VISA_ENDS_DATE" )
    public String touristVisaEndsDate;

    @Column(name = "MIGRATED_FROM" )
    public String migratedFrom;

    @Column(name = "MIGRATED_DATE" )
    public String migratedDate;

    @Column(name = "COMMUNITY" )
    public String community;

    @Column(name = "CURRENT_LOCATION" )
    public String currentLocation;

    @Column(name = "NO_OF_DAYS_LIVED_IN_CURRENT_LOCATION" )
    public String noOfDaysLivedInCurrentLocation;

    @Column(name = "CIVIL_CONDUCT_REMARKS" )
    public String civilConductRemarks;

    @Column(name = "DESCRIPTION" )
    public String description;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsTourist() {
		return isTourist;
	}

	public void setIsTourist(String isTourist) {
		this.isTourist = isTourist;
	}

	public String getIsResident() {
		return isResident;
	}

	public void setIsResident(String isResident) {
		this.isResident = isResident;
	}

	public String getHasValidVisa() {
		return hasValidVisa;
	}

	public void setHasValidVisa(String hasValidVisa) {
		this.hasValidVisa = hasValidVisa;
	}

	public String getIsInfiltrated() {
		return isInfiltrated;
	}

	public void setIsInfiltrated(String isInfiltrated) {
		this.isInfiltrated = isInfiltrated;
	}

	public String getIsConverted() {
		return isConverted;
	}

	public void setIsConverted(String isConverted) {
		this.isConverted = isConverted;
	}

	public String getPreviousReligion() {
		return previousReligion;
	}

	public void setPreviousReligion(String previousReligion) {
		this.previousReligion = previousReligion;
	}

	public String getCurrentReligion() {
		return currentReligion;
	}

	public void setCurrentReligion(String currentReligion) {
		this.currentReligion = currentReligion;
	}

	public String getTouristVisaEndsDate() {
		return touristVisaEndsDate;
	}

	public void setTouristVisaEndsDate(String touristVisaEndsDate) {
		this.touristVisaEndsDate = touristVisaEndsDate;
	}

	public String getMigratedFrom() {
		return migratedFrom;
	}

	public void setMigratedFrom(String migratedFrom) {
		this.migratedFrom = migratedFrom;
	}

	public String getMigratedDate() {
		return migratedDate;
	}

	public void setMigratedDate(String migratedDate) {
		this.migratedDate = migratedDate;
	}

	public String getCommunity() {
		return community;
	}

	public void setCommunity(String community) {
		this.community = community;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}

	public String getNoOfDaysLivedInCurrentLocation() {
		return noOfDaysLivedInCurrentLocation;
	}

	public void setNoOfDaysLivedInCurrentLocation(String noOfDaysLivedInCurrentLocation) {
		this.noOfDaysLivedInCurrentLocation = noOfDaysLivedInCurrentLocation;
	}

	public String getCivilConductRemarks() {
		return civilConductRemarks;
	}

	public void setCivilConductRemarks(String civilConductRemarks) {
		this.civilConductRemarks = civilConductRemarks;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "DomainEntity [id=" + id + ", name=" + name + ", isTourist=" + isTourist + ", isResident=" + isResident
				+ ", hasValidVisa=" + hasValidVisa + ", isInfiltrated=" + isInfiltrated + ", isConverted=" + isConverted
				+ ", previousReligion=" + previousReligion + ", currentReligion=" + currentReligion
				+ ", touristVisaEndsDate=" + touristVisaEndsDate + ", migratedFrom=" + migratedFrom + ", migratedDate="
				+ migratedDate + ", community=" + community + ", currentLocation=" + currentLocation
				+ ", noOfDaysLivedInCurrentLocation=" + noOfDaysLivedInCurrentLocation + ", civilConductRemarks="
				+ civilConductRemarks + ", description=" + description + "]";
	}
    
    
}
