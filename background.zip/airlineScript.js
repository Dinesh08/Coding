function login(username,password){
	console.log("User clicked")
	if(username=="admin" && password=="admin"){
		sessionStorage.setItem('login', true);
		window.location.replace("bookingForm.html");
	}else{
		sessionStorage.removeItem('login');
		alert("Username or password is wrong");
	}
}

function loginCheck(){
	if(!sessionStorage.getItem("login")){
		window.location.replace("airline form.html");
	}
	document.getElementById('hidden').style.display = 'none'
	document.getElementById('src').checked=true;
	setTimeout(function(){ 
		sessionStorage.removeItem('login');
	}, 10000);
}

function tripCheck(name){
	if(name=='src'){
		document.getElementById('hidden').style.display = 'none'
	}else{
		document.getElementById('hidden').style.display = 'block'
	}
	
}

function onsubmit(){
	console.log('sgfdf')
}